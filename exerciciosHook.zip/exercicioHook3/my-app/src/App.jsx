import './App.css'
import Delivery from './deliveryStatus/delivery';
function App() {
  return (
    <>
      <Delivery/>
    </>
  )
}

export default App;
