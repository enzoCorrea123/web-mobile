import Input from './input/input';
import './App.css'

function App() {
  return (
    <>
      <Input/>

    </>
  )
}

export default App;
